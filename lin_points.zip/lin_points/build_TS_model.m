close all;
clear all;
clc;

addpath(genpath(fullfile(pwd,'./non_linear_model_functions')))
addpath(genpath(fullfile(pwd,'./non_linear_model_functions/config_setup_files')))
addpath(genpath(fullfile(pwd,'./TS_model_functions')))

make_TS_model()