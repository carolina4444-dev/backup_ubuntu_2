function [c,ceq] = mycon(iterative_and_aprox_point)
    global radius f lreminder_function aprox_degree total_linearization_points n_variables minimum_acceptable_distance;
    x = iterative_and_aprox_point(1:n_variables);
    aprox_point_ = iterative_and_aprox_point(n_variables+1:end);
    aprox_point=format_to_shape(aprox_point_,[total_linearization_points,n_variables])';
    
    c = []; % c(x) <= 0 for all entries of c.
    ceq = []; % ceq(x) = 0 for all entries of ceq.
    inner=0;
    c_idx = 1;
    for idx=1:total_linearization_points
        for n=1:n_variables
            inner = inner+sum(power(x(n)-aprox_point(n,idx),2)/power(radius(n),2));
            c(c_idx)=abs(x(n)-aprox_point(n,idx))-minimum_acceptable_distance; 
            c_idx = c_idx+1;
        end
        c(c_idx) = inner-1;
        c_idx = c_idx+1;
    end  
    c(c_idx)=all(abs(diff(aprox_point,1))-minimum_acceptable_distance,[1,2]);
end