% function [ARR,IRR,x1_k_1, x2_k_1, x3_k_1] = modelo_TS(x1, x2, x3, u1, u2)%(input)%
function [x1_k_1, x2_k_1, x3_k_1] = modelo_TS(x1, x2, x3, u1, u2)

    global Ts;
    global fis;
    
    %input = [x1_fuzzy(index), x2_fuzzy(index), x3_fuzzy(index), u1(index), u2(index)]
    
    %input=[x1 x2 x3 u1 u2]
    input = [x1, x2, x3, u1, u2];
   
    [output_vector] = evalfis(fis, input);
    

    
    x1_k_1 = output_vector(1);
    x2_k_1 = output_vector(2);
    x3_k_1 = output_vector(3);

end