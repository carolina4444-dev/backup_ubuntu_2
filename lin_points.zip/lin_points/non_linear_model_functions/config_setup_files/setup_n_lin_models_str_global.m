%STRING VARIABLES

%diferential equations strings

%diferential equations

global dx1_dt_str
global dx3_dt_str
global dx2_dt_str