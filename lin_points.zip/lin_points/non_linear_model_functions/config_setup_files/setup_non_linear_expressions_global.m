
%STATE AND INPUT VARIABLES
global x1 x2 x3 u1 u2;


%DIFERENTIAL EQUATION VARIABLES
% global Q1;
% global q_10;
% global q_13;
% 
% global q_30;
% global q_32;
% 
% global Q2;
% global q_20;
% global q_3;


global dx1_dt;
global dx2_dt;
global dx3_dt;


global matrix_A_generic matrix_B_generic function_at_point_generic;

global model_variables_str;




