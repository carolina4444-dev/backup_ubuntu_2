% Non linear model defined as strings
%*****************************
% % VARIABLES DEFINED HERE:
% ->Adding terms defined as strings of nonlinear model without signal
% ->States diferential equations named dx1_dt_str,...,dxN_dt_str
%   Defined as: dx1_dt_str = { {+/-1}, {term1},...,{+/-1}, {termX} }
%****************************


% % SUBSTITUIR POR b1_BOMBA1, 
% % q1= b1_BOMBA1 <-> valores_poli_BOMBA1(1)*U1+valores_poli_BOMBA1(2)
% % q2= b1_BOMBA2 <-> valores_poli_BOMBA2(1)*U2+valores_poli_BOMBA2(2)
% % 
% % ADICIONAR A PASTA SCRIPT DA PEN MAIN _TK CAROLINA USADO PARA A EX+ERIENCIA

%diferential equations strings

Q1_str = '(u(1)*valores_poli_BOMBA1_M+valores_poli_BOMBA1_B)/S';

q_10_str = 'alfa_10*Sn*sign(x(1))*sqrt(2*a_gravidade*abs(x(1)))/S';

q_13_str = 'alfa_13*Sn*sign(x(1)-x(3))*sqrt(2*a_gravidade*abs(x(1)-x(3)))/S';

q_30_str = 'alfa_30*Sn*sign(x(3))*sqrt(2*a_gravidade*abs(x(3)))/S'; 

q_32_str = 'alfa_32*Sn*sign(x(3)-x(2))*sqrt(2*a_gravidade*abs(x(3)-x(2)))/S';

Q2_str = '(u(2)*valores_poli_BOMBA2_M+valores_poli_BOMBA2_B)/S';

q_20_str = 'alfa_20*Sn*sign(x(2))*sqrt(2*a_gravidade*abs(x(2)))/S';

q_3_str = 'alfa_3*Sn*sign(x(2))*sqrt(2*a_gravidade*abs(x(2)))/S';


%completar expressoes com influencias dos caudais corrigidas:
dx1_dt_str=[{'+1'},{Q1_str},...
    {'-1'},{q_13_str}];

dx3_dt_str=[{'+1'},{q_13_str},...
        {'-1'},{q_32_str}];
    
dx2_dt_str=[{'+1'},{q_32_str},...
    {'-1'},{q_3_str},...
    {'+1'},{Q2_str}];



