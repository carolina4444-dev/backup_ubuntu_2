load('/home/carolina/Documentos/lin_points/non_linear_model_functions/config_setup_files/variaveis_modelo.mat')
x=who('-file','/home/carolina/Documentos/lin_points/non_linear_model_functions/config_setup_files/variaveis_modelo.mat');

for idx=1:size(x)
    name=x(idx);
    name=name{:};
    eval(['global ',name,';']);
end