% Non linear model defined as symfun 
%**********************************************************
% % VARIABLES DEFINED HERE:
% syms x1,...,xN
% syms u1,...,uM
% Non linear model terms as symfun, might use the model variables defined
%  at setup_model_variables.m file
% States diferential equations as symfun named dx1_dt,...,dxN_dt
%
%Obs: define_partial_derivatives script is previously saved at
%configuration_X/setup_files_configX
%*********************************************************



%STATE VARIABLES
%x1,x2,..,x_number_of_state_vars
syms x1 x2 x3;


%INPUT VARIABLES
%u1,u2,...,u_number_of_input_vars
syms u1 u2;


%************diferential equation definition**************

%contributions
Q1 = symfun( u1*valores_poli_BOMBA1_M+valores_poli_BOMBA1_B ,[u1]);

q_10 = symfun( alfa_10*Sn*sign(x1)*sqrt(2*a_gravidade*abs(x1)) ,[x1]);
        
q_13 = symfun( alfa_13*Sn*sign(x1-x3)*sqrt(2*a_gravidade*abs(x1-x3)) ,[x1,x3]);
   
q_30 = symfun( alfa_30*Sn*sign(x3)*sqrt(2*a_gravidade*abs(x3)) ,[x3]);

q_32 = symfun( alfa_32*Sn*sign(x3-x2)*sqrt(2*a_gravidade*abs(x3-x2)) ,[x2,x3]);

Q2 = symfun( u2*valores_poli_BOMBA2_M+valores_poli_BOMBA2_B ,[u2]);
    
q_20 = symfun( alfa_20*Sn*sign(x2)*sqrt(2*a_gravidade*abs(x2)) ,[x2]);
    
q_3 = symfun( alfa_3*Sn*sign(x2)*sqrt(2*a_gravidade*abs(x2)) ,[x2]);


%diferential equations
total_valves_dx1=[{'+'},{'Q1(u1)'},...
    {'-'},{'q_10(x1)'},...
    {'-'},{'q_13(x1,x3)'}];


total_valves_dx3=[{'+'},{'q_13(x1,x3)'},...
        {'-'},{'q_32(x2,x3)'},...
        {'-'},{'q_30(x3)'}]; 
    
  
total_valves_dx2 = [{'+'},{'Q2(u2)'},...
    {'+'},{'q_32(x2,x3)'},...
    {'-'},{'q_3(x2)'},...
    {'-'},{'q_20(x2)'}];


valves_names=[{'q_10(x1)'},{'q_13(x1,x3)'},{'q_30(x3)'},{'q_32(x2,x3)'},{'q_20(x2)'},{'q_3(x2)'}];
total_valves_names=[{'total_valves_dx1'},{'total_valves_dx3'},{'total_valves_dx2'}];

for v_numb=1:length(valves_states)    %[q10_state, q13_state, q30_state, q32_state, q20_state, q3_state];
    
    cur_valve_state=valves_states(v_numb);
    
    %corrigir valvulas nao consideradas 
    if(~cur_valve_state)
        
        %remover em todos os vectors, o efeito da valvula atual
        for vector_name_idx=1:length(total_valves_names)
            
            cur_name_str=total_valves_names{vector_name_idx};
            
            rm_index = eval(strcat('find(strcmp(',cur_name_str,', valves_names{v_numb}));'));
            
            if(~isempty(rm_index))             
                eval(strcat(cur_name_str,'(rm_index-1:rm_index)=[];'));
            end

        end       
        
    end
    
end


%influencias dos caudais completas, atribuir expressao final

expressions_names=[{'dx1_dt'},{'dx3_dt'},{'dx2_dt'}];

for vector_name_idx=1:length(expressions_names)
    
    cur_expr_name = expressions_names{vector_name_idx};
    
    cur_expr = eval(strcat('[',total_valves_names{vector_name_idx},'{:}]'));
    
    if(isempty(cur_expr))
        eval(strcat(cur_expr_name,'=symfun( 0 ,[x1,x2,x3,u1,u2]);'));
    else
        eval(strcat(cur_expr_name,'=symfun( (',cur_expr,')/S ,[x1,x2,x3,u1,u2]);'));
    end
    
end

%************diferential equation definition**************

%num script a parte:
define_partial_derivatives();


