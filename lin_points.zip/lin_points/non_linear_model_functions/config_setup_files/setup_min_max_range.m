%*************************************
% % VARIABLES DEFINED HERE:
% number_of_state_vars
% number_of_input_vars
% STATES_RANGE
% STATES_MODEL_RANGE
% INPUTS_RANGE
% INPUTS_MODEL_RANGE
% state_vars_with_integral_action
% number_of_added_svars
% ie_state_vars_number
% IE_MODEL_RANGE
%*************************************

%NUMBER OF INPUT AND STATE VARIABLES
number_of_state_vars=3;
number_of_input_vars=2;
n_variables=number_of_state_vars+number_of_input_vars;

%RANGES
%states working ranges
STATES_RANGE(1,:)=[0, 0.62];    %state abs_X1
STATES_RANGE(2,:)=[0, 0.62];   %state abs_X2
STATES_RANGE(3,:)=[0, 0.62];   %state abs_X2

%states model ranges
STATES_MODEL_RANGE(1,:)=[-100000, 100000];    %state abs_X1
STATES_MODEL_RANGE(2,:)=[-100000, 100000];    %state abs_X2
STATES_MODEL_RANGE(3,:)=[-100000, 100000];

%inputs working range
INPUTS_RANGE(1,:)=[1, 5];    %input abs_U1
INPUTS_RANGE(2,:)=[1, 5];    %input abs_U2

%inputs model ranges
INPUTS_MODEL_RANGE(1,:)=[-100000, 100000];    %input U1
INPUTS_MODEL_RANGE(2,:)=[-100000, 100000];    %input U2




% %********extended model options********commented, not consided for ts
% modulation problem
% 
% %in a string cell array, same name defined at setup_non_linear_expressions.m
% state_vars_with_integral_action = {'x1'};  
% 
% 
% number_of_added_svars = length(state_vars_with_integral_action);
% 
% %obter numero das variaveis de estado com acao integral
% ie_state_vars_number=zeros(1,number_of_added_svars);
% for ie_var=1:number_of_added_svars
% 	ie_state_vars_number(ie_var)=str2num(state_vars_with_integral_action{ie_var}(2));
% end
% 
% 
% %integral errors range
% IE_MODEL_RANGE(1,:)=[-100000, 100000];    %state variables integral errors 


