
global number_of_state_vars
global number_of_input_vars
global STATES_RANGE
global STATES_MODEL_RANGE
global INPUTS_RANGE
global INPUTS_MODEL_RANGE
% global state_vars_with_integral_action
% global number_of_added_svars
% global ie_state_vars_number
% global IE_MODEL_RANGE