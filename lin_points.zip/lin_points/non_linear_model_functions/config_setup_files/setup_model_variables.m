%PHYSICAL MODEL variables

%*****************************
% % VARIABLES DEFINED HERE:
% Ts (sampling period)
% Any other variable to use in the nonlinear model definition
%*****************************


%load('./non_linear_model_functions/config_setup_files/variaveis_modelo.mat')
load('/home/carolina/Documentos/lin_points/non_linear_model_functions/config_setup_files/variaveis_modelo.mat')