close all; clear all; clc;

%addpath('./non_linear_model_functions')
addpath('./config_setup_files')

%declarar globals
setup_n_lin_models_str_global();
setup_model_variables_global();
setup_min_max_range_global();

%atribuir globals
setup_min_max_range();
setup_n_lin_models_str();
setup_model_variables();

setup_non_linear_expressions_global();
setup_non_linear_expressions();

%%%%%%%%%%%%%%%%%%%%%%%

MAX_TEST_ITERATIONS = 10; % 158;%157;%3->4
STEP_SIZE = MAX_TEST_ITERATIONS/4;


% load modelo TS
global fis;
fis = readfis('../fis_model_structure');


u_M=2.5*ones(MAX_TEST_ITERATIONS,2);
x_N=zeros(MAX_TEST_ITERATIONS,3);

x_fuzzy=zeros(MAX_TEST_ITERATIONS,3);
dx_fuzzy=zeros(MAX_TEST_ITERATIONS,3);

initial_conditions=zeros(3,1);


for k=2:MAX_TEST_ITERATIONS
     
    
    %if(k>1)
       %[x_fuzzy(k,1), x_fuzzy(k,2), x_fuzzy(k,3)] = modelo_TS( x_fuzzy(k-1,1), x_fuzzy(k-1,2), x_fuzzy(k-1,3), u_M(k,1), u_M(k,2));
       [x_fuzzy(k,1), x_fuzzy(k,2), x_fuzzy(k,3)] = modelo_TS( x_fuzzy(k-1,1), x_fuzzy(k-1,2), x_fuzzy(k-1,3), u_M(k,1), u_M(k,2));
       %[dx1_fuzzy, dx2_fuzzy, dx3_fuzzy] = modelo_TS( x_fuzzy(k-1,1), x_fuzzy(k-1,2), x_fuzzy(k-1,3), u_M(k,1), u_M(k,2));
       
    %end
    
%      x_fuzzy(k,1)=x_fuzzy(k-1,1)+Ts*dx1_fuzzy;
%      x_fuzzy(k,2)=x_fuzzy(k-1,2)+Ts*dx2_fuzzy;
%      x_fuzzy(k,3)=x_fuzzy(k-1,3)+Ts*dx3_fuzzy;
    dx_fuzzy(k,1) = (x_fuzzy(k,1)-x_fuzzy(k-1,1))/Ts;
    dx_fuzzy(k,2) = (x_fuzzy(k,2)-x_fuzzy(k-1,2))/Ts; 
    dx_fuzzy(k,3) = (x_fuzzy(k,3)-x_fuzzy(k-1,3))/Ts;

    %create input array
    u=u_M(k,:); %u e um vector linha com as atuacoes do instante k
    
    %%%modelo nao linear
    x = modelo_n_linear_continuo_sampled(Ts,initial_conditions,u);
    initial_conditions=x';
    
    %atribuicao das output samples pelos n vectores de simulacao
    x_N(k,:)=x;
         
end



plot(1:MAX_TEST_ITERATIONS, x_fuzzy(:,1),'g',...
    1:MAX_TEST_ITERATIONS, x_N(:,1),'r');
hold on

plot(1:MAX_TEST_ITERATIONS, x_fuzzy(:,2),'g',...
    1:MAX_TEST_ITERATIONS, x_N(:,2),'r');
hold on

plot(1:MAX_TEST_ITERATIONS, x_fuzzy(:,3),'g',...
    1:MAX_TEST_ITERATIONS, x_N(:,3),'r');


plot(1:MAX_TEST_ITERATIONS, dx_fuzzy(:,1),'g',...
    1:MAX_TEST_ITERATIONS, x_N(:,1),'r');
hold on

plot(1:MAX_TEST_ITERATIONS, dx_fuzzy(:,2),'g',...
    1:MAX_TEST_ITERATIONS, x_N(:,2),'r');
hold on

plot(1:MAX_TEST_ITERATIONS, dx_fuzzy(:,3),'g',...
    1:MAX_TEST_ITERATIONS, x_N(:,3),'r');

% plot(1:MAX_TEST_ITERATIONS,x1_fuzzy,'b',...
%     1:MAX_TEST_ITERATIONS, x1,'y');
% 
% save check_data.mat x1 x2 x3

%plot derivadas modelo difuso, derivadas modelo linear
% plot(1:MAX_TEST_ITERATIONS,x1_fuzzy,'b',...
%     1:MAX_TEST_ITERATIONS, x1,'y',...
%     1:MAX_TEST_ITERATIONS, balance_points(index_pe).x1_balance*ones(MAX_TEST_ITERATIONS,1),'g');

% plot(1:MAX_TEST_ITERATIONS,x1_fuzzy,'b',...
%     1:MAX_TEST_ITERATIONS,balance_points(index_pe).x1_balance*ones(MAX_TEST_ITERATIONS,1),'y');



% % %plot ponto de equilibrio resultado teste
% plot(1:MAX_TEST_ITERATIONS, x1_fuzzy,'b',...
%     1:MAX_TEST_ITERATIONS, balance_points(index_pe).x1_balance*ones(MAX_TEST_ITERATIONS,1),'g');


% %X1
% plot(1:MAX_TEST_ITERATIONS,x1_fuzzy,'b',...
%     1:MAX_TEST_ITERATIONS, x1,'r',...
%     1:MAX_TEST_ITERATIONS, balance_points(index_pe).x1_balance*ones(MAX_TEST_ITERATIONS,1),'g')

%plot(1:MAX_TEST_ITERATIONS, x1,'r',1:MAX_TEST_ITERATIONS, balance_points(index_pe).x1_balance*ones(MAX_TEST_ITERATIONS,1),'g')

% %X1
% plot(1:MAX_TEST_ITERATIONS,x1_fuzzy,...
%     1:MAX_TEST_ITERATIONS, balance_points(index_pe).x1_balance*ones(MAX_TEST_ITERATIONS,1))

% %X2
% plot(1:MAX_TEST_ITERATIONS,x2_fuzzy,...
%     1:MAX_TEST_ITERATIONS, balance_points(index_pe).x2_balance*ones(MAX_TEST_ITERATIONS,1))


% plot(1:MAX_TEST_ITERATIONS,x1_fuzzy,1:MAX_TEST_ITERATIONS,x2_fuzzy,1:MAX_TEST_ITERATIONS,x3_fuzzy)
    

