function [xN_k_1] = modelo_n_linear_disc(u, x, Ts)
    
    [dxNdt] = odefun(1,x,u)';
    
    xN_k_1=dxNdt.*Ts+x;

end