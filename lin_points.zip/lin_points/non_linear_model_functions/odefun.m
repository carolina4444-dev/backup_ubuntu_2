function [dxNdt] = odefun(t, x, u)

    %setup_model_variables
    run('./config_setup_files/setup_model_variables.m')

    %setup_min_max_range
    run('./config_setup_files/setup_min_max_range.m')

    %setup_n_lin_models_str
    run('./config_setup_files/setup_n_lin_models_str.m')

    %u=x(number_of_state_vars+1:end);
    %x=x(1:number_of_state_vars);
    
    dxNdt=zeros(number_of_state_vars,1);
   
    for state_var=1:number_of_state_vars    
        
        array_name=strcat('dx',num2str(state_var),'_dt_str');
        number_of_terms=eval(strcat('length(',array_name,')'));
        
        value=0;
        
        for n_term=1:2:number_of_terms           
            signal=eval(strcat(array_name,'{',num2str(n_term),'}'));             
            signal=eval(signal);
            
            value_term=eval(strcat(array_name,'{',num2str(n_term+1),'}'));         
            value_term=eval(value_term);
    %       value_term=eval(value_term);
            
            value=value+(signal)*(value_term);
        end
        
        dxNdt(state_var)=value;
        
    end
 

end