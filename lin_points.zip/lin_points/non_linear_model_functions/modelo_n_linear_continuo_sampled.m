function [output_sample] = modelo_n_linear_continuo_sampled(Ts,initial_conditions,u)

    duration=[0, Ts];
    
    %x=[initial_conditions; u'];

    [t,x] = ode45(@(t,x)odefun(t,x,u), duration, initial_conditions);
    
    output_sample=x(end,:);

end
