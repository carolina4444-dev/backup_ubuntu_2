function [] = inicialize_simulation_arrays(MAX_TEST_ITERATIONS)
    
    evalin('caller','initial_conditions=zeros(1,number_of_state_vars);');
    
    %u(k) controler
    evalin('caller','u=zeros(1,number_of_input_vars);');
    
    %number_of_input_vars
    evalin('caller',strcat('u_M=zeros(',num2str(MAX_TEST_ITERATIONS),',number_of_input_vars);'));
    
    %x(k) model
    evalin('caller','x=zeros(1,number_of_state_vars);');
    
    %number_of_state_vars
    evalin('caller',strcat('x_N=zeros(',num2str(MAX_TEST_ITERATIONS),',number_of_state_vars);'));

end

