%define derivatives taylor model (DYNAMIC))))))

%run('setup_model_variables.m'); %comment because aleready in the workspace
%setup_min_max_range();
    

syms matrix_A_generic matrix_B_generic function_at_point_generic

%calc matrix A
for equation_Svar_num=1:number_of_state_vars %lines

    for state_var_num=1:number_of_state_vars %colums

        matrix_A_generic(equation_Svar_num,state_var_num) =...
            eval(strcat('diff(dx',num2str(equation_Svar_num),'_dt,x',num2str(state_var_num),');'));

    end
    
    function_at_point_generic(equation_Svar_num,1)=eval(strcat('dx',num2str(equation_Svar_num),'_dt'));
        
end
    
    
%calc matrix B
for equation_Svar_num=1:number_of_state_vars %lines

    for input_var_num=1:number_of_input_vars %colums

        matrix_B_generic(equation_Svar_num,input_var_num) =...
            eval(strcat('diff(dx',num2str(equation_Svar_num),'_dt,u',num2str(input_var_num),');'));

    end

end

same_B=not( strcmp(class( eval(matrix_B_generic) ),'sym') );

%define model_variables_str
model_variables_str=cell(number_of_state_vars+number_of_input_vars,1);

for state_number=1:number_of_state_vars       
    model_variables_str{state_number}=strcat('x',num2str(state_number));
end

for input_number=1:number_of_input_vars   
    model_variables_str{number_of_state_vars+input_number}=strcat('u',num2str(input_number));   
end
model_variables_str = strjoin(model_variables_str,', ');
model_variables_str=strcat('{',model_variables_str,'}');
    
%avaliar no ponto 
% df_h3_dx1(1, 2, 6, 2, 2)
   
   
   