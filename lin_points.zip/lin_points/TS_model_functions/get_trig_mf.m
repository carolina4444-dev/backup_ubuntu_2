function [f_pertenca] = get_trig_mf(center_points)

    setup_model_variables_global();
    setup_min_max_range_global();
    
    global number_of_state_vars number_of_input_vars;
    
    %STATES        
    for state_number=1:number_of_state_vars
        
        pes_xN = center_points(state_number,:);
        pes_xN = unique(pes_xN);
        
        eval(strcat('f_pertenca.x',num2str(state_number),'= definir_funcoes_pertenca(pes_xN);'));     
        
        X_MIN=STATES_RANGE(state_number,1);
        X_MAX=STATES_RANGE(state_number,2);
                
        eval(strcat('f_pertenca.x',num2str(state_number),'_range_min= X_MIN;'));
        
        eval(strcat('f_pertenca.x',num2str(state_number),'_range_max= X_MAX;'));
        
        eval(strcat('f_pertenca.x',num2str(state_number),'_centros= pes_xN;'));
        
    end
    
    
    
    %INPUTS
    input_idx = number_of_state_vars+1;
    
    for input_number=1:number_of_input_vars
        
        pes_uN = center_points(input_idx,:);
        pes_uN = unique(pes_uN);
        
        eval(strcat('f_pertenca.u',num2str(input_number),'= definir_funcoes_pertenca(pes_uN);'));     
        
        U_MIN=INPUTS_RANGE(input_number,1);
        U_MAX=INPUTS_RANGE(input_number,2);
        
        eval(strcat('f_pertenca.u',num2str(input_number),'_range_min= U_MIN;'));
        
        eval(strcat('f_pertenca.u',num2str(input_number),'_range_max= U_MAX;'));
        
        eval(strcat('f_pertenca.u',num2str(input_number),'_centros= pes_uN;'));
        
        input_idx=input_idx+1;
    end
    

end