function [rules,ctrlb_error_status] = create_model_rules(f_pertenca)

    ctrlb_error_status=0;
    %extrair centros funcoes de pertenca variaveis
    global number_of_state_vars number_of_input_vars;
    
    antecedent_var_names = cell(1,number_of_state_vars+number_of_input_vars);
        
    mf_centers = cell(number_of_state_vars+number_of_input_vars,1);
     
  
    %STATES
    for state_number=1:number_of_state_vars  
        %extrair centros das funcoes de pertenca para atribuir aos antecedentes
        mf_centers{state_number}=eval(strcat('extractfield(f_pertenca,',char(39), 'x',num2str(state_number),'_centros',char(39),');'));
        
        %construir parametros para o combvec
        antecedent_var_names{state_number}=strcat('mf_centers{',num2str(state_number),'}');
    
        %construir parametros para avaliacao dinamica das derivadas
        %parciais no ponto
      end
    
    for input_number=1:number_of_input_vars
        %extrair centros das funcoes de pertenca para atribuir aos antecedentes
        mf_centers{number_of_state_vars+input_number}=eval(strcat('extractfield(f_pertenca,',char(39), 'u',num2str(input_number),'_centros',char(39),');'));
        
        %construir parametros para o combvec
        antecedent_var_names{number_of_state_vars+input_number}=strcat('mf_centers{',num2str(number_of_state_vars+input_number),'}');
    
        %construir parametros para avaliacao dinamica das derivadas
        %parciais no ponto
      end
 %   balance_point_str = strjoin(balance_point_str,', ');
    
    antecedent_var_names = strjoin(antecedent_var_names,', '); 
    
    total_antecedentes = eval(strcat('combvec(',antecedent_var_names,');'));
    
%build model   
for index=1:size(total_antecedentes,2)
    
    %obter indexs das funcoes de pertenca consideradas no antecedente
    rules(index).antecedent=zeros(length(mf_centers),1);
    for antecedent_number=1:length(mf_centers)
                
        rules(index).antecedent(antecedent_number)=...
            find(mf_centers{antecedent_number}==total_antecedentes(antecedent_number,index));
                                                 %current_pe_x1 = total_antecedentes(1,index);   
    end  
   
    
    %calculo do consequente
    x_pe=total_antecedentes(1:number_of_state_vars,index);
    u_pe=total_antecedentes(number_of_state_vars+1:end,index);
    
    [A,B,constant_component,function_at_point,ERROR] = get_Taylor_model(x_pe, u_pe);

    %teste de controlabilidade do modelo gerado
    %if( rank(ctrb(A,B))<size(A,1) || ERROR)
    if( ERROR )
        disp('ERROR generated model is not controlable or contains division br zero!!')
        ctrlb_error_status=1;
        return
    end

    rules(index).consequent.matrix_A = A;
    rules(index).consequent.matrix_B = B;
    rules(index).consequent.constant_component = constant_component;
    rules(index).consequent.function_at_point = function_at_point;
    rules(index).consequent.x_lin = x_pe;
    rules(index).consequent.u_lin = u_pe;
   
%     disp([num2str(index) ' de ' num2str(length(total_antecedentes))]); 
    
end


%save regras.mat regra centros_fp_x1 centros_fp_x2 centros_fp_x3 centros_fp_u1 centros_fp_u2 regra2

end

