function [fis] = funcoes_pertenca2struct(fis, aprox_points_final, f_pertenca)

    setup_min_max_range_global();

    last_index = size(aprox_points_final, 2);
    
%     fis_vars = {};
%     var = fisvar([0 1]);
%     var = addMF(var);
%     var.MembershipFunctions(1).Type = "trapmf";
%     var.MembershipFunctions(1).Parameters = [-0.5 0 0.2 0.4];

    for index=1:last_index
        vector_estruturas(index).name = num2str(index);
        vector_estruturas(index).type = 'trimf';
        vector_estruturas(index).params = vector_funcoes(index,:);
        
        fis = eval('addMF(fis,',strcat('"x',num2str(state_number),'"'),"trimf",strcat('f_pertenca.x',num2str(index)));
    end
    
   
    if(is_state)
        X_MIN_ACEPT_MODEL = STATES_MODEL_RANGE(var_number,1);
        X_MAX_ACEPT_MODEL = STATES_MODEL_RANGE(var_number,2);
            
        if(last_index~=1)        
            vector_estruturas(1).type = 'trapmf';
            vector_estruturas(1).params = [X_MIN_ACEPT_MODEL-1 X_MIN_ACEPT_MODEL vector_funcoes(1,2:3)];

            vector_estruturas(end).type = 'trapmf';
            vector_estruturas(end).params = [vector_funcoes(end,1:2) X_MAX_ACEPT_MODEL X_MAX_ACEPT_MODEL+1];

        else
            vector_estruturas(1).type = 'trapmf';
            vector_estruturas(1).params = [X_MIN_ACEPT_MODEL-1 X_MIN_ACEPT_MODEL X_MAX_ACEPT_MODEL X_MAX_ACEPT_MODEL+1];      
        end

    else %is input
        U_MIN = INPUTS_MODEL_RANGE(var_number,1);
        U_MAX = INPUTS_MODEL_RANGE(var_number,2);
        
        if(last_index~=1)  
            vector_estruturas(1).type = 'trapmf';
            vector_estruturas(1).params = [U_MIN-1 U_MIN vector_funcoes(1,2:3)];

            vector_estruturas(end).type = 'trapmf';
            vector_estruturas(end).params = [vector_funcoes(end,1:2) U_MAX U_MAX+1];      
        
        else
            vector_estruturas(1).type = 'trapmf';
            vector_estruturas(1).params = [U_MIN-1 U_MIN U_MAX U_MAX+1];      
        end
    end
    
    %add membership functions following library's syntax    
%     vars_array={}
%     var = fisvar([0 9]);
%     for idx=1:lenght(vector_estruturas)
%         
%         vars_array{idx} = addMF(,"trimf",[0 3 6],'LowerScale',1);
%     end
    
    
end