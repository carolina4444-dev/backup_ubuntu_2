%close all; clear all; clc;

function [] = make_TS_model()

addpath(genpath(fullfile(pwd,'./non_linear_model_functions')))
addpath(genpath(fullfile(pwd,'./non_linear_model_functions/config_setup_files')))

%declarar globals
setup_n_lin_models_str_global();
setup_model_variables_global();
setup_min_max_range_global(); %loads model_variables, so comment setup_model_variables()

%atribuir globals
setup_min_max_range();
setup_n_lin_models_str();
%setup_model_variables();

setup_non_linear_expressions_global();
setup_non_linear_expressions();

save ./non_linear_model_functions/config_setup_files/same_B.mat same_B

%carregar pontos de linearizacao escolhidos
setup_linearization_points();

%criar funcoes de pertenca
[f_pertenca] = get_trig_mf(choosed_model_points);

[rules,ctrlb_error_status] = create_model_rules(f_pertenca);

%atribuicao da estrutura modelo TS
[fis] = atribue_fuzzy_inference_system_structure(rules,f_pertenca);


%save model
choosed_combination.rule=rules;
choosed_combination.f_pertenca=f_pertenca;
save choosed_combination.mat choosed_combination





