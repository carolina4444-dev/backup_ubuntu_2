function [rules_consequents, vector_regras] = get_consequentes_by_var(regra)

    setup_min_max_range_global();

    %para cada regra
    for index=1:length(regra)
        
        %extrair parametros do consequente
        matriz_A = regra(index).consequent.matrix_A;       
        matriz_B = regra(index).consequent.matrix_B;
        componente_cte = regra(index).consequent.constant_component;
                
        %atribuir os consequentes afins do output
        %existem tantos outputs com variaveis de estado
        for output_number=1:number_of_state_vars
            
            field_name=strcat('vector_consequentes_x',num2str(output_number));
                        
            cur_consequent.name = strcat('modelo_x',num2str(output_number),'_',num2str(index));
            cur_consequent.type = 'linear';
            cur_consequent.params = [matriz_A(output_number,:) matriz_B(output_number,:) componente_cte(output_number,:)];
                    
            rules_consequents.(field_name)(index)=cur_consequent;
            
        end

        %atribuir relacao antecedente->consequente a regra presente
        %extrair parametros do antecedente
        rule_antecedent = regra(index).antecedent'; %[x1 x2 x3 u1 u2] declarado pela mesma ordem que os inputs do fis!!!
              
        %definir REGRA
        vector_regras(index).weight = 1;
        vector_regras(index).connection = 1;
        
        vector_regras(index).antecedent = rule_antecedent;
        eval(['vector_regras(index).consequent = [',strjoin([repmat({'index'},1,number_of_state_vars)]),'];'])
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
%         %atribuir o consequente do modelo desta regra a cada variavel de
%         %output x1(k+1), x2(k+1), x3(k+1)
%         %X1
%         vector_consequentes_x1(index).name = strcat('modelo_x1_',num2str(index));
%         vector_consequentes_x1(index).type = 'linear';       
%         %assumindo que params [x1 x2 x3 u1 u2 cte]
%         vector_consequentes_x1(index).params = [matriz_A(1,:) matriz_B(1,:) componente_cte(1,:)];
%         
%         %X2
%         vector_consequentes_x2(index).name = strcat('modelo_x2_',num2str(index));
%         vector_consequentes_x2(index).type = 'linear';       
%         %assumindo que params [x1 x2 x3 u1 u1 cte]
%         vector_consequentes_x2(index).params = [matriz_A(2,:) matriz_B(2,:) componente_cte(2,:)];        
%         
%         %X3
%         vector_consequentes_x3(index).name = strcat('modelo_x3_',num2str(index));
%         vector_consequentes_x3(index).type = 'linear';       
%         %assumindo que params [x1 x2 x3 u1 u1 cte]
%         vector_consequentes_x3(index).params = [matriz_A(3,:) matriz_B(3,:) componente_cte(3,:)];
%         
        

        
        
        %nos outputs os consequentes teem a mesma ordem da regra a que
        %correspondem, assim como os seus nomes sao o index
        
    end
    
end