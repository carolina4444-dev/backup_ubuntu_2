function [fis] = atribue_fuzzy_inference_system_structure(regra,f_pertenca)

setup_min_max_range_global();
load('found_lin_points.mat')

% f_pertenca=[choosed_combination.f_pertenca];
% 
% regra=[choosed_combination.rule];

% fis = newfis('fis',...
%     'fisType','sugeno',...
%     'andMethod','min',...
%     'orMethod','max',...
%     'impMethod','min',...
%     'aggMethod','max',...
%     'defuzzMethod','wtaver');

fis = sugfis(...
    'AndMethod','prod',...
    'OrMethod','max',...
    'ImplicationMethod','prod',...
    'AggregationMethod','sum',...
    'DefuzzificationMethod','wtaver'); %vector of fisrule objects
%     'Inputs', [],... %vector of fisvar objects
%     'Outputs', [],... %vector of fisvar objects
fis.Rules = [];
%******************* atribuir campo de input *******************
    %input_variables = [];
    last_index = size(aprox_points_final, 1);
    %atribuir inputs estados
    for state_number=1:number_of_state_vars
        
        fis = addInput(fis);
        fis.Inputs(state_number).Name = strcat('x',num2str(state_number));
        fis.Inputs(state_number).Range = [STATES_MODEL_RANGE(state_number,:)];
        
        for idx=1:last_index
            %add membership functions for current input
            fis = eval(strcat('addMF(fis, "x',num2str(state_number),'","trimf",[f_pertenca.x',num2str(state_number),'(',num2str(idx),',:)])'));
        end
        
        %first and last fuzzzy sets of the discourse universe are trapez
        X_MIN_ACEPT_MODEL = STATES_MODEL_RANGE(state_number,1);
        X_MAX_ACEPT_MODEL = STATES_MODEL_RANGE(state_number,2);

        if(last_index~=1)  
            %remove triangulars
            fis = removeMF(fis, strcat("x",num2str(state_number)), 'mf1');
            fis = removeMF(fis, strcat("x",num2str(state_number)), strcat('mf', num2str(last_index)));
            %add trapezoids
            fis = addMF(fis, strcat("x",num2str(state_number)), "trapmf", [X_MIN_ACEPT_MODEL-1 X_MIN_ACEPT_MODEL eval(strcat('f_pertenca.x',num2str(state_number),'(1,2:3)'))]); 
            fis = addMF(fis, strcat("x",num2str(state_number)), "trapmf", [eval(strcat('f_pertenca.x',num2str(state_number),'(end,1:2)')) X_MAX_ACEPT_MODEL X_MAX_ACEPT_MODEL+1]); 
        else
            %remove triangulars
            fis = removeMF(fis, strcat("x",num2str(state_number)), 'mf1');
            %add trapezoids
            fis = addMF(fis, strcat("x",num2str(state_number)), "trapmf", [X_MIN_ACEPT_MODEL-1 X_MIN_ACEPT_MODEL X_MAX_ACEPT_MODEL X_MAX_ACEPT_MODEL+1]);      
        end
    end
    

    
    
    %atribuir inputs atuacoes
    for input_number=1:number_of_input_vars
        
        input_index=input_number+number_of_state_vars;
        
        fis = addInput(fis);
        fis.Inputs(input_index).Name = strcat('u',num2str(input_number));
        fis.Inputs(input_index).Range = [INPUTS_MODEL_RANGE(input_number,:)];
        
        for idx=1:last_index
            %add membership functions for current input
            fis = eval(strcat('addMF(fis, "u',num2str(input_number),'","trimf",[f_pertenca.u',num2str(input_number),'(',num2str(idx),',:)])'));
        end
    
        %first and last fuzzy sets are trapez
        U_MIN = INPUTS_MODEL_RANGE(input_number,1);
        U_MAX = INPUTS_MODEL_RANGE(input_number,2);

        if(last_index~=1)   
            %remove triangulars
            fis = removeMF(fis, strcat("u",num2str(input_number)), 'mf1');
            fis = removeMF(fis, strcat("u",num2str(input_number)), strcat('mf', num2str(last_index)));
            %add trapezoids
            fis = addMF(fis, strcat("u",num2str(input_number)), "trapmf", [U_MIN-1 U_MIN eval(strcat('f_pertenca.u',num2str(input_number),'(1,2:3)'))]); 
            fis = addMF(fis, strcat("u",num2str(input_number)), "trapmf", [eval(strcat('f_pertenca.u',num2str(input_number),'(end,1:2)')) U_MAX U_MAX+1]); 
        else
            %remove triangulars
            fis = removeMF(fis, strcat("u",num2str(input_number)), 'mf1');
            %add trapezoids
            fis = addMF(fis, strcat("u",num2str(input_number)), "trapmf", [U_MIN-1 U_MIN U_MAX U_MAX+1]);      
        end
        
    end
    

% %X1
% fis.input(1).name = 'x1';
% fis.input(1).range = [X_MIN_ACEPT_MODEL, X_MAX_ACEPT_MODEL];
% fis.input(1).mf = funcoes_pertenca2struct(f_pertenca.x1,1);
% 
% %X2
% fis.input(2).name='x2';
% fis.input(2).range = [X_MIN_ACEPT_MODEL, X_MAX_ACEPT_MODEL];
% fis.input(2).mf = funcoes_pertenca2struct(f_pertenca.x2,1);
% 
% %X3
% fis.input(3).name='x3';
% fis.input(3).range = [X_MIN_ACEPT_MODEL, X_MAX_ACEPT_MODEL];
% fis.input(3).mf = funcoes_pertenca2struct(f_pertenca.x3,1);

% %U1
% fis.input(4).name='u1';
% fis.input(4).range = [U_MIN_ACEPT_MODEL, U_MAX_ACEPT_MODEL];
% fis.input(4).mf = funcoes_pertenca2struct(f_pertenca.u1,0);
% 
% %U2
% fis.input(5).name='u2';
% fis.input(5).range = [U_MIN_ACEPT_MODEL, U_MAX_ACEPT_MODEL];
% fis.input(5).mf = funcoes_pertenca2struct(f_pertenca.u2,0);


%******************* atribuir campo de output *******************
total_rules = size(regra,2);
%rules_consequent_idx = zeros(total_rules,number_of_state_vars+number_of_input_vars);
for output_number=1:number_of_state_vars

    fis.Outputs(output_number).Name = strcat('x',num2str(output_number),'_k_1');
    fis.Outputs(output_number).Range = STATES_MODEL_RANGE(output_number,:);
    
    for rule_idx=1:total_rules
    
        fis.Outputs(output_number).MembershipFunctions(rule_idx).Type = "linear";
        fis.Outputs(output_number).MembershipFunctions(rule_idx).Parameters = [regra(rule_idx).consequent.matrix_A(output_number,:), regra(rule_idx).consequent.matrix_B(output_number,:), regra(rule_idx).consequent.constant_component(output_number)];
        %fis.Outputs(output_number).MembershipFunctions(rule_idx).Parameters = [regra(rule_idx).consequent.matrix_A(output_number,:), regra(rule_idx).consequent.matrix_B(output_number,:), regra(rule_idx).consequent.function_at_point(output_number)];
        %fis.Outputs(output_number).MembershipFunctions(rule_idx).Parameters = [regra(rule_idx).consequent.matrix_A(output_number,:), regra(rule_idx).consequent.matrix_B(output_number,:), 0];
        %rules_consequent_idx(rule_idx,output_number) = rule_idx;
    end
end

fis.Rules = [];
for idx=1:total_rules
    
    
    
    %generate rule description
    %"x1==mf1 & x2==mf1 & x3==mf1 & u1==mf1 & u2==mf2 => x1(k+1)=mf1, x2(k+1)=mf1, x3(k+1)=mf1";
    description = "";
    description_consequent = "";
    for state_idx=1:number_of_state_vars
        description = strcat(description, " ",'x',num2str(state_idx),' == mf',num2str(regra(idx).antecedent(state_idx))," ",'&'," ");
        description_consequent = strcat(description_consequent, " ",'x',num2str(state_idx),'_k_1=mf',num2str(idx),','," ");
    end
    u_idx = number_of_state_vars+1;
    for act_idx=1:number_of_input_vars
        description = strcat(description," ",'u',num2str(act_idx),'==mf',num2str(regra(idx).antecedent(u_idx))," ",'&'," ");
        u_idx = u_idx+1;
    end
    description = extractBetween(description,1,strlength(description)-2);
    description_consequent = extractBetween(description_consequent,1,strlength(description_consequent)-2);
    description = strcat(description, " ", ' => '," ",description_consequent," ");
    
    for out_n=1:number_of_state_vars
        %rule = fisrule(description);
        %fis = addRule(fis,rule);
        %rule = update(rule, fis);
        %rule = fisrule;
        %
        %rule = update(rule, fis);
        rule = fisrule;
        rule.Description = description;
        rule = update(rule, fis);
        rule.Antecedent = regra(idx).antecedent';
        rule.Consequent = idx.*ones(1,number_of_state_vars);
        rule.Weight = 1;    %same weight for all  rules
        rule.Connection = 1; %Evaluate rule antecedents using the AND operator
        %fis=addrule(rule,fis)
        fis.Rules(idx) = rule;

        
    end
end

%save fis to file
writeFIS(fis,'fis_model_structure');



end
