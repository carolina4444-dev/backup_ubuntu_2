function funcoes = definir_funcoes_pertenca(pontos_eq)

    total_pes = length(pontos_eq);
    funcoes = ones(total_pes,3); % [x_vertice_min x_vertice_meio x_vertice_max]
    
    if(total_pes==1)
        funcoes=[pontos_eq-1,pontos_eq,pontos_eq+1];
    else
        %casos especiais
        %primeira funcao de pertenca

        funcoes(1,:)=[pontos_eq(1),...
           pontos_eq(1), ...
           pontos_eq(2)];

        %ultima funcao de pertenca

        funcoes(total_pes,:)=[pontos_eq(end-1),...
            pontos_eq(end),...
            pontos_eq(end)];

        %funcoes de pertenca intermedias
        if(total_pes>2)
            for k=2:total_pes-1

                funcoes(k,:)=[pontos_eq(k-1),...
                    pontos_eq(k),...
                    pontos_eq(k+1)];
            end
        end
    
    end

end