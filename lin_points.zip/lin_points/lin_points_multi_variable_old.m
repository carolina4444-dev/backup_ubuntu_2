close all;
clear all;
clc;
%variables declaration
x = sym('x',[1, 2]);

%configuration
n_variables = 2;
total_linearization_points = 4;

f = sin(x(1)+x(2));
aprox_point = [1,1];
aprox_degree = 1;

domain = [0, pi/2;...
    0, pi/2];

%functions
%taylor_function = taylor(f, x, 'ExpansionPoint', aprox_point, 'Order', aprox_degree);
lreminder_function = lagrange_remainder_multi_variable(x, f, aprox_point, aprox_degree);

global lreminder_function aprox_point;

%calculate minimum remainder -> best case scenario
x0 = domain(1:n_variables);
lb = domain(1:n_variables);
ub = domain(1:n_variables, 2:end);
%options = optimoptions('fmincon','Display','iter','OutputFcn',@outfun);


[x, total_aprox_error] = fmincon(@lagrange_remainder_value,x0,[],[],[],[],lb,ub)



