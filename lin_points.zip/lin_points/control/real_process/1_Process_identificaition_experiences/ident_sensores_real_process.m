% demo dts200 tk3
clc, clear all, close all

TOTAL_PONTOS=15;

% [leitura sensor, real]
pontos_caracteristica_S_TK1=zeros(TOTAL_PONTOS,2);
pontos_caracteristica_S_TK3=zeros(TOTAL_PONTOS,2);
pontos_caracteristica_S_TK2=zeros(TOTAL_PONTOS,2);

for ponto=1:TOTAL_PONTOS
    
    xdaq.xpto = 1; xdaq = usbdaq('Dev5','init',xdaq); % init DAQ; % USB daq struct
    xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev5','writ',xdaq); % write an initial value

    time.tmax = input('Tmax[s]= ? ');
    time.Ts = 1; time.kmax = round(time.tmax/time.Ts);

    tensaoB1 = input('tensaoB1= ? ');
    tensaoB2 = input('tensaoB2= ? ');

    for k = 1:time.kmax

        %leitura  
        xdaq = usbdaq('Dev5','read',xdaq); [xdaq.y(:)]';

        xdaq.u = [tensaoB1 tensaoB2]; xdaq = usbdaq('Dev5','writ',xdaq);

        pause(time.Ts);
    end

    xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev5','writ',xdaq); % write an initial value

    leitura_pronta = input('leitura_pronta ? ');

    %leitura  
    xdaq = usbdaq('Dev5','read',xdaq); [xdaq.y(:)]';
    
    pontos_caracteristica_S_TK1(ponto,1)= xdaq.y(4);
    pontos_caracteristica_S_TK1(ponto,2)=input('TK1 leitura ocular em mm');
    
    pontos_caracteristica_S_TK3(ponto,1)= xdaq.y(2);
    pontos_caracteristica_S_TK3(ponto,2)=input('TK3 leitura ocular em mm');
    
    pontos_caracteristica_S_TK2(ponto,1)= xdaq.y(3);
    pontos_caracteristica_S_TK2(ponto,2)=input('TK2 leitura ocular em mm');
    

    disp('*****************************************');
end

save pontos_caracteristicas_S.mat pontos_caracteristica_S_TK1 pontos_caracteristica_S_TK2 pontos_caracteristica_S_TK3

%intrepertacao leitura sensor
% xdaq.y(4) -> altura TK1 (esquerda)
% xdaq.y(3) -> altura TK2 (direita)
% xdaq.y(2) -> altura TK3 (centro)

% eof