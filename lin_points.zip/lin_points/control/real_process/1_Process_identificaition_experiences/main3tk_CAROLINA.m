% demo dts200 tk3
clc, clear all, close all

xdaq.xpto = 1; xdaq = usbdaq('Dev4','init',xdaq); % init DAQ; % USB daq struct
xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev4','writ',xdaq); % write an initial value

time.tmax = input('Tmax[s]= ? ');
time.Ts = 1; time.kmax = round(time.tmax/time.Ts);

tensaoB1 = input('tensaoB1= ? ');
tensaoB2 = input('tensaoB2= ? ');

for k = 1:time.kmax
    xdaq = usbdaq('Dev4','read',xdaq); [xdaq.y(:)]'
    
    xdaq.u = [tensaoB1 tensaoB2]; xdaq = usbdaq('Dev4','writ',xdaq);
    
    pause(time.Ts);
end

xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev4','writ',xdaq); % write an initial value

% eof