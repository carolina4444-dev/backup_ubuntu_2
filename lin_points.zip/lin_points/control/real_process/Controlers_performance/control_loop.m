% demo dts200 tk3
clc, clear all, close all

% configuracao 1
test_configuration=1;

controller_type='run_results_simple_region';
% run_results_simple_region
% run_results_choosed_region

path2save='step_response_data_NEW_stepp';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
STEP_SIZE=200;

% ref_x=1*10^-3.*[100*ones(STEP_SIZE,1),100*ones(STEP_SIZE,1);...
%     55*ones(STEP_SIZE,1),30*ones(STEP_SIZE,1);...
%     70*ones(STEP_SIZE,1),60*ones(STEP_SIZE,1);...
%     40*ones(STEP_SIZE,1),30*ones(STEP_SIZE,1);...
%     20*ones(STEP_SIZE,1),20*ones(STEP_SIZE,1)];

ref_x=1*10^-3.*[100*ones(STEP_SIZE,1),100*ones(STEP_SIZE,1)];

MAX_TEST_ITERATIONS = size(ref_x,1);


addpath('sensors_characteristic');
addpath('TS_controllers');

run('TS_controllers/setup_min_max_range.m');
U_MIN_SAT=INPUTS_RANGE(1,1);
U_MAX_SAT=INPUTS_RANGE(1,2);

%initialize variables
u_M=zeros(MAX_TEST_ITERATIONS,number_of_input_vars);
x_N=zeros(MAX_TEST_ITERATIONS,number_of_state_vars);

%load Ts controller
controller_path=['TS_controllers/config_',num2str(test_configuration),'/',...
    controller_type,'/fis_structure_controler'];

fis_controler=readfis(controller_path);



%load Ts constant controller
controller_path=['TS_controllers/config_',num2str(test_configuration),'/',...
    controller_type,'/constant_fis_controler'];

fis_constant_controler=readfis(controller_path);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%inicializacoes placa
xdaq.xpto = 1; xdaq = usbdaq('Dev5','init',xdaq); % init DAQ; % USB daq struct
xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev5','writ',xdaq); % write an initial value

time.tmax = MAX_TEST_ITERATIONS; %input('Tmax[s]= ? ');                   %tempo maximo da experiencia=num amostras
time.Ts = 1; time.kmax = round(time.tmax/time.Ts); 


for t = 2:time.kmax
      
    %generate control action
    
    x_past_real=x_N(t-1,:);
    u_past=u_M(t-1,:);   
    ref_past=ref_x(t-1,:);
    
    %calcular atuacao controlador  current_configuration
    constant_u = TS_controller_constant(x_past_real, u_past, fis_constant_controler);
    
    
    u_M(t,:) = TS_controller(x_past_real,u_past,ref_past,fis_controler);
    
    

    %saturacao acao de controlo
    u_M(t,:) = max( min(U_MAX_SAT,u_M(t,:)), U_MIN_SAT);

    
    %atuacao
    u=u_M(t,:);
    %[tensaoB1, tensaoB2]
    xdaq.u = u; xdaq = usbdaq('Dev5','writ',xdaq);
    tic;
    
    %pause(time.Ts-toc);
    
    pause(time.Ts-toc);
    
    %leitura   
    xdaq = usbdaq('Dev5','read',xdaq);  [xdaq.y(:)];
    
        
    %leitura, conversao de volt->metros
    x_N(t,:) = sensor_read2meter(xdaq.y(:));
        x_N(t,:)      
end


%escrever [0,0] na placa
xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev5','writ',xdaq); % write an initial value

eval(['save ',path2save,'/step_experience_config_',num2str(test_configuration),'_controller_',controller_type,'.mat x_N u_M ref_x'])


% eof


plot(1:time.kmax,x_N(:,1),'b',...
    1:time.kmax,ref_x(:,1),'g')

plot(1:time.kmax,x_N(:,2),'b',...
    1:time.kmax,ref_x(:,2),'g')






