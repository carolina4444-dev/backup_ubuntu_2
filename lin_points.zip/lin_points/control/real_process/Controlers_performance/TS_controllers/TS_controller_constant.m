function [output_vector] = TS_controller_constant(s_vars, u, fis_controler)
    
    input = [s_vars, u];
       
    [output_vector,IRR,ORR,ARR] = evalfis(input, fis_controler);
    
end