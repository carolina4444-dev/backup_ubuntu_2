%*************************************
% % VARIABLES DEFINED HERE:
% number_of_state_vars
% number_of_input_vars
% STATES_RANGE
% STATES_MODEL_RANGE
% INPUTS_RANGE
% INPUTS_MODEL_RANGE
% state_vars_with_integral_action
% number_of_added_svars
% ie_state_vars_number
% IE_MODEL_RANGE
%*************************************

%NUMBER OF INPUT AND STATE VARIABLES
number_of_state_vars=3;
number_of_input_vars=2;

%RANGES
%states working ranges
STATES_RANGE(1,:)=[0, 1];    %state X1
STATES_RANGE(2,:)=[0, 1];    %state X2
STATES_RANGE(3,:)=[0, 1];    %state X3

%states model ranges
STATES_MODEL_RANGE(1,:)=[-100000, 100000];    %state X1
STATES_MODEL_RANGE(2,:)=[-100000, 100000];    %state X2
STATES_MODEL_RANGE(3,:)=[-100000, 100000];    %state X3

%inputs working range
INPUTS_RANGE(1,:)=[0, 10];    %input U1
INPUTS_RANGE(2,:)=[0, 10];    %input U2

%inputs model ranges
INPUTS_MODEL_RANGE(1,:)=[-100000, 100000];    %input U1
INPUTS_MODEL_RANGE(2,:)=[-100000, 100000];    %input U2


%extended model options
state_vars_with_integral_action = {'x1','x2'};

number_of_added_svars = length(state_vars_with_integral_action);

%obter numero das variaveis de estado com acao integral
ie_state_vars_number=zeros(1,number_of_added_svars);
for ie_var=1:number_of_added_svars
	ie_state_vars_number(ie_var)=str2num(state_vars_with_integral_action{ie_var}(2));
end


%integral errors range
IE_MODEL_RANGE(1,:)=[-100000000, 100000000];    %state variables integral errors 
IE_MODEL_RANGE(2,:)=[-100000000, 100000000];    %to consider


%FUNCTION CHECK INPUTS
%verifica as dimensoes inseridas, se erro disp error,
%chamar aqui


