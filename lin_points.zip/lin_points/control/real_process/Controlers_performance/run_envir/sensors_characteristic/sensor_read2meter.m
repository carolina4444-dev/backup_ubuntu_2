% function [h_TK1_m, h_TK2_m, h_TK3_m] = sensor_read2meter(y_xdaq)
function [convertions] = sensor_read2meter(ydaq)

    % linearCoefficients
    load('parametros_caracteristica_sensores_altura.mat');
    total_sensors = size(linearCoefficients,1);
    convertions = zeros(1,total_sensors);

    % intrepertacao leitura sensor
    % xdaq.y(4) -> altura TK1 (esquerda)
    % xdaq.y(3) -> altura TK2 (direita)
    % xdaq.y(2) -> altura TK3 (centro)
    
%     u_sensorTK1 = ydaq(4);
%     u_sensorTK2 = ydaq(3);
%     u_sensorTK3 = ydaq(2);

    u_sensorTK1 = ydaq(2);
   
    u_sensorTK3 = ydaq(4);
    
    
 u_sensorTK2 = ydaq(3);
    % conversao V -> m
    for sensor = 1:total_sensors
        
        poli_values = linearCoefficients(sensor,:);       
        eval(['convertions(sensor) = polyval(poli_values,u_sensorTK',num2str(sensor),');']) 
    end
        
end