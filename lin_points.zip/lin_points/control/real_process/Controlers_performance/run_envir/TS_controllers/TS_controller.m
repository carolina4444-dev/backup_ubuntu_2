function [output_vector] = TS_controller(s_vars, i_e, u, ref_x, fis_controler)
    
    input = [s_vars, i_e, u, ref_x];
       
    [output_vector,IRR,ORR,ARR] = evalfis(input, fis_controler);
    
end