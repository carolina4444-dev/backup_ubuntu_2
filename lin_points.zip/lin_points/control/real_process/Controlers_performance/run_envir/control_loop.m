% demo dts200 tk3
clc, clear all, close all

addpath('sensors_characteristic');
addpath('TS_controllers');
run('TS_controllers/setup_min_max_range.m');

%path2save='step_response_data/simple_controllers/';

path2save='variable_ref_data/choosed_controllers/';

test_configuration=3;
%comentario com estados valvulas

%actuation's saturation values ARE THE SAME!!
U_MIN_SAT=INPUTS_RANGE(1,1);
U_MAX_SAT=INPUTS_RANGE(1,2);


STEP_SIZE=75;   
MAX_TEST_ITERATIONS = 4*STEP_SIZE;

ref_x=1*10^-3.*[70*ones(STEP_SIZE,1),70*ones(STEP_SIZE,1);...
    100*ones(STEP_SIZE,1),50*ones(STEP_SIZE,1);...
    30*ones(STEP_SIZE,1),40*ones(STEP_SIZE,1);...
    75*ones(STEP_SIZE,1),75*ones(STEP_SIZE,1)];

% MAX_TEST_ITERATIONS = 100;
% ref_x=0.06.*ones(MAX_TEST_ITERATIONS,2);

%initialize variables
u_M=zeros(MAX_TEST_ITERATIONS,number_of_input_vars);
x_N=zeros(MAX_TEST_ITERATIONS,number_of_state_vars);
i_e=zeros(MAX_TEST_ITERATIONS,number_of_added_svars);

%load Ts controller
fis_controler=readfis(['TS_controllers/conf_',num2str(test_configuration),'/',...
    'fis_structure_controler']);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%inicializacoes placa
xdaq.xpto = 1; xdaq = usbdaq('Dev5','init',xdaq); % init DAQ; % USB daq struct
xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev5','writ',xdaq); % write an initial value

time.tmax = MAX_TEST_ITERATIONS; %input('Tmax[s]= ? ');                   %tempo maximo da experiencia=num amostras
time.Ts = 1; time.kmax = round(time.tmax/time.Ts); 

% tensaoB1 = input('tensaoB1= ? ');
% tensaoB2 = input('tensaoB2= ? ');

% ltePRBS(162,4,'signed'); sequencia binaria pseudo alleatoria de tamanho 4


for t = 2:time.kmax
      
    %generate control action
   
    x_past_real=x_N(t-1,:);
    u_past=u_M(t-1,:);
 %   ie_past=i_e(t-1,:)+ref_x(t,:);
    ie_past=i_e(t-1,:);
    
    cur_ref=ref_x(t,:);
    
    %calcular atuacao controlador  current_configuration
    u_M(t,:) = TS_controller(x_past_real,ie_past,u_past,cur_ref,fis_controler);
    
    
    %saturacao acao de controlo
    u_M(t,:) = max( min(U_MAX_SAT,u_M(t,:)), U_MIN_SAT);

    
    %atuacao
    u=u_M(t,:);
    %[tensaoB1, tensaoB2]
    xdaq.u = u; xdaq = usbdaq('Dev5','writ',xdaq);
    tic;
    
    %pause(time.Ts-toc);
    
    pause(time.Ts-toc);
    
    %leitura   
    xdaq = usbdaq('Dev5','read',xdaq);  [xdaq.y(:)];
    
        
    %leitura, conversao de volt->metros
    x_N(t,:) = sensor_read2meter(xdaq.y(:));
        x_N(t,:)
    %calculo do integral do erro de seguimento
    i_e(t,:)=i_e(t-1,:)+ref_x(t,:)-x_N(t,ie_state_vars_number);
          
end


%escrever [0,0] na placa
xdaq.u = [0.0 0.0]; xdaq = usbdaq('Dev5','writ',xdaq); % write an initial value

eval(['save ',path2save,'TS_controller_conf_',num2str(test_configuration),'_experience_data.mat x_N u_M ref_x'])


% eof


plot(1:time.kmax,x_N(:,1),'b',...
    1:time.kmax,ref_x(:,1),'g')

plot(1:time.kmax,x_N(:,2),'b',...
    1:time.kmax,ref_x(:,2),'g')






