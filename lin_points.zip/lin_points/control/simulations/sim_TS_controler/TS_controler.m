function [output_vector] = TS_controler(s_vars, i_e, u, fis_controler)
    
    input = [s_vars, i_e, u];
       
    [output_vector,IRR,ORR,ARR] = evalfis(input, fis_controler);
    
end