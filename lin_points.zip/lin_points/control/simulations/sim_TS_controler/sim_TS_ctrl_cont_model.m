close all; clear all; clc;

% TS controler + non linear model simulation for a given reference signal
%  ref_X
% Please configure this part of the script:
% atention to the TS controler working range

% path to fis_structure_controler.fis file with TS model
% Ex:. run_results/XXXfolderXXX/fis_structure_controler.fis
fis_controler_folder = '../../../run_results/run_results_simple/fis_structure_controler.fis';

% ../../../run_results/run_results_region/fis_structure_controler.fis
% ../../../run_results/run_results_simple/fis_structure_controler.fis

% max simulation iterations
MAX_IT = 100;

% reference signal, dimentions = MAX_IT x number_of_added_svars
ref_x=pi/3*ones(MAX_IT,1);

% initial state, dimentions = 1 x number_of_state_vars
x_0=[0,0];

% end of configuration
% ****** simulation *************************************************

% non linear model simulation functions
addpath(genpath('../non_lin_model_functions'))
addpath(genpath('../../../interface/setup_n_lin_model'))

%setup model variables
run('setup_min_max_range.m')
run('setup_model_variables.m')

% load TS controler
TS_controler_struct = readfis(fis_controler_folder);

% initialize simulation vectors
x_N=[x_0;zeros(MAX_IT-1,number_of_state_vars)];
u_M=zeros(MAX_IT,number_of_input_vars);
i_e=zeros(MAX_IT,number_of_added_svars);


for t=3:MAX_IT

    %generate control action
    x_past_real=x_N(t-1,:);
    u_past=u_M(t-1,:);   
    ie_past=i_e(t-2,:);  
    ie_input_past=ref_x(t-1,:)+ie_past;
    
    %calcular atuacao controlador  current_configuration
    u_M(t,:) = TS_controler(x_past_real,ie_input_past,u_past,TS_controler_struct);

    %continuous model
    u_cur=u_M(t,:);
    initial_conditions=x_N(t-1,:)';
    
    x_N(t,:)=modelo_n_linear_continuo_sampled(Ts,initial_conditions,u_cur);
    
    
    %calculo do integral do erro de seguimento
    i_e(t,:)=i_e(t-1,:)+ref_x(t,:)-x_N(t,ie_state_vars_number);
    
end
rmpath(genpath('../non_lin_model_functions'))
rmpath(genpath('../../../interface/setup_n_lin_model'))

%remove first samples
x_N=x_N(3:end,:);
u_M=u_M(3:end,:);
ref_x=ref_x(3:end,:);
MAX_TEST_ITERATIONS=size(ref_x,1);

% end of simulation
% ****** plots ******

subplot(211)
plot(x_N(:,1),'b');
hold on
plot(ref_x(:,1),'b--');
%xlim([1 30])
title('Controller C_{2}');
ylabel('x_{1} (rad)');
xlabel('Time (s)');
xt=get(gca,'xtick');
set(gca,'xticklabel',arrayfun(@num2str,xt*Ts,'un',0));

subplot(212)
plot(u_M(:,1),'b');
%ylim([-5500 3100])
%xlim([1 30])
ylabel('u (N)');
xlabel('Time (s)');
xt=get(gca,'xtick');
set(gca,'xticklabel',arrayfun(@num2str,xt*Ts,'un',0));

save region_controler.mat u_M ref_x x_N

%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %plot
% subplot(211)
% 
% plot(x_N(:,1), 'b');
% hold on
% plot(ref_x(:,1), '--b');
% ylim([0 0.15])
% title('Variavel de Estado X1');
% ylabel('H Fluido (m)');
% xlabel('Tempo (s)');
% legend('Modelo Continuo','Referencia','Location','southeast'); 
% 
% subplot(212)
% 
% plot(x_N(:,2), 'b');
% hold on
% plot(ref_x(:,2), '--b');
% ylim([0 0.15])
% title('Variavel de Estado X2');
% ylabel('H Fluido (m)');
% xlabel('Tempo (s)');
% legend('Modelo Continuo','Referencia','Location','southeast'); 
% 


