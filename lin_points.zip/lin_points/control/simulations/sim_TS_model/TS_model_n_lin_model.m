close all; clear all; clc;

addpath(genpath(fullfile(pwd,'../../non_linear_model_functions')))
addpath(genpath(fullfile(pwd,'../../non_linear_model_functions/config_setup_files')))
addpath(genpath(fullfile(pwd,'../../TS_model_functions')))

% TS model + non linear model simulation for a given input signal u_M
% Please configure this part of the script:
% atention to the TS model working range

% path to fis_model_structure.fis file with TS model
% Ex:. run_results/XXXfolderXXX/fis_model_structure.fis
fis_model_folder = '../../../fis_model_structure';

% ../../../run_results/run_results_region/fis_model_structure.fis
% ../../../run_results/run_results_simple/fis_model_structure.fis

% max simulation iterations
MAX_IT = 40;

% actuation signal, dimentions = MAX_IT x number_of_input_vars
u_M=1*ones(MAX_IT,2);

% initial state, dimentions = 1 x number_of_state_vars
x_0=[0,0,0];

% check if your TS model inputs,
% -> if inputs = state variables, use simulation function
%   "sim_TS_model_x_input"
% -> if inputs = state variables + actuation variables, use simulation 
%   function "sim_TS_model_xu_input"
%   coment above the non used one

% end of configuration
% ****** simulation *******************************************

% non linear model simulation functions
%addpath(genpath('../non_lin_model_functions'))
%addpath(genpath('../../../interface/setup_n_lin_model'))

%setup model variables
run('setup_min_max_range.m')
run('setup_model_variables.m')

% load TS model
TS_model_struct = readfis(fis_model_folder);

% initialize state vector
x_N_n_lin=[x_0;zeros(MAX_IT-1,number_of_state_vars)];
x_N_fuzzy=[x_0;zeros(MAX_IT-1,number_of_state_vars)];

% simulation loop

for t=2:MAX_IT

    u = u_M(t,:);
    
    % sim TS model with state and actuation variables as input
    x_N_fuzzy(t,:) = sim_TS_model_xu_input(x_N_fuzzy(t-1,:), u, TS_model_struct);
 
%     % sim TS model with state variables as input
%     x_N_fuzzy(t,:) = sim_TS_model_x_input(x_N_fuzzy(t-1,:), TS_model_struct);

    
    % sim non linear model
    x_N_n_lin(t,:) = modelo_n_linear_continuo_sampled(Ts, x_N_n_lin(t-1,:)', u);
         
end
rmpath(genpath('../non_lin_model_functions'))
rmpath(genpath('../../../interface/setup_n_lin_model'))

% end of simulation
% ****** plots ******
state_var = 1;
input_var = 1;

plot(1:MAX_IT, x_N_fuzzy(:,state_var), 'g',...
    1:MAX_IT, x_N_n_lin(:,state_var), 'r',...
    1:MAX_IT, u_M(:,input_var))






