% Input variables:
%   x = [x1, ..., xN] at time instant t
%   u = [u1, ..., uM]
%   TS_model_struct, loaded .fis structure
% Output variables:
%   x_t_1 = [x1, ..., xN] at time instant t+1
function [x_t_1] = sim_TS_model_x_input(x, TS_model_struct)

    [x_t_1,IRR,ORR,ARR] = evalfis(x, TS_model_struct);
    
end