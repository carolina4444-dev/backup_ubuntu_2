% Input variables:
%   x = [x1, ..., xN] at time instant t
%   u = [u1, ..., uM]
%   TS_model_struct, loaded .fis structure
% Output variables:
%   x_t_1 = [x1, ..., xN] at time instant t+1
function [x_t_1] = sim_TS_model_xu_input(x, u, TS_model_struct)

    input = [x, u];
       
    [x_t_1] = evalfis(TS_model_struct,input);
    
end