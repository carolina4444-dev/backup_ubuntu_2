function[lag_rem] = lagrange_remainder(f, aprox_point, aprox_degree, symbolic_variables)
   derivative_term = diff(f, aprox_degree+1);
   factorial_term = factorial(aprox_degree+1);
   
   lag_rem = (derivative_term/factorial_term)*power(symbolic_variables-aprox_point,aprox_degree+1);
end