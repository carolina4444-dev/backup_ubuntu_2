%create elipse for discourse universe
%connect with ts fuzzy model function

%variables declaration
%x = sym('x',1:n_variables);
for idx=1:number_of_state_vars
    eval(strcat('global x',string(idx),';'))
end
for idx=1:number_of_input_vars
    eval(strcat('global u',string(idx),';'))
end
aprox_point = sym('aprox_point', [total_linearization_points, n_variables]);

%functions
%taylor_function = taylor(f, x, 'ExpansionPoint', aprox_point, 'Order', aprox_degree);

global minimum_acceptable_distance radius f lreminder_function aprox_degree total_linearization_points...
    n_variables number_of_state_vars number_of_input_vars x0;

%calculate minimum remainder -> best case scenario
lb = domain(1:n_variables+n_variables*total_linearization_points)';
ub = domain(1:n_variables+n_variables*total_linearization_points,2:end);
%options = optimoptions('fmincon','Display','iter','OutputFcn',@outfun);
nonlcon = @mycon;

options = optimoptions('fmincon','Algorithm','sqp');
[aprox_point, total_aprox_error] = fmincon(@lagrange_remainder_multi_variable,x0,[],[],[],[],lb,ub,nonlcon);

%get aproximation points
x_iter = aprox_point(1:n_variables);
aprox_points_final = aprox_point(n_variables+1:end);
aprox_points_final=reshape(aprox_points_final,[total_linearization_points,n_variables]);

save found_lin_points.mat aprox_points_final

