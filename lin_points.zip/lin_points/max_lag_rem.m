function [cur_error] = max_lag_rem(x_star)

    global func symbolic_array number_of_state_vars number_of_input_vars;
    for idx=1:number_of_state_vars
        eval(strcat('global x',string(idx),';'))
    end
    for idx=1:number_of_input_vars
        eval(strcat('global u',string(idx),';'))
    end
    
   
   %preform substitutions, possibly division by zero
   try
       temp = eval(strcat('subs(func,{',symbolic_array,'}, x_star);'));
       cur_error = sum(sum(abs(eval(temp))));
   catch
       cur_error = -9e+9999; 
       return;
   end
   
end

