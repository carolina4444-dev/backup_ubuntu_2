close all;
clear all;
clc;
%variables
syms x1

f = sin(x1);
aprox_point = 1;
aprox_degree = 1;
symbolic_variables = [x1];

domain_x1 = [0, pi/2];

ft = taylor(f, symbolic_variables, 'ExpansionPoint', aprox_point, 'Order', aprox_degree)
fr = lagrange_remainder(f, aprox_point, aprox_degree, symbolic_variables)
