function [final] = format_to_shape(input_array, shape2d)
    final=[]; 
    line=1;
    for column=1:shape2d(2):size(input_array,2)
        final(line,1:shape2d(2))=input_array(1,column:column+shape2d(2)-1);
        line=line+1;
    end
end

