function [A,B,constant_component,function_at_point,ERROR] = get_Taylor_model(x_pe, u_pe)

        ERROR=0;

        setup_model_variables_global();
        setup_min_max_range_global();
        setup_non_linear_expressions_global();
        
        %x_pe, u_pe are colum vectors
        balance_point =  [x_pe',u_pe'];%[x_pe',u_pe'];
        
        %construir parametro para eval
        bp_input_model_str=cell(1,number_of_state_vars+number_of_input_vars);
        for model_v_numb=1:number_of_state_vars+number_of_input_vars
            bp_input_model_str{model_v_numb}=num2str(balance_point(model_v_numb));
        end      
        bp_input_model_str = strjoin(bp_input_model_str,',');
     %   bp_input_model_str=strcat('{',bp_input_model_str,'}');

%******************criacao dos consequentes******************
    %subs(matrix_B_generic,{u1,u2},{0,0})
    try
        
        %Taylor matrixs at balance point
        eval(strcat('matrix_A_pe=subs(matrix_A_generic,',model_variables_str,',{',bp_input_model_str,'});'));
        A=eval(matrix_A_pe);

        eval(strcat('matrix_B_pe=subs(matrix_B_generic,',model_variables_str,',{',bp_input_model_str,'});'));
        B=eval(matrix_B_pe);
        
        eval(strcat('function_at_point=subs(function_at_point_generic,',model_variables_str,',{',bp_input_model_str,'});'));
        function_at_point=eval(function_at_point);   

    catch ME
        ERROR=1;
        A=[];
        B=[];
        constant_component=[];
        function_at_point=[];
        return
    end
     
    %calculo do restante modelo
  
    constant_component = function_at_point+A*(-1.*x_pe)+B*(-1.*u_pe);
    
    
    %discretize_model
    C=eye(size(matrix_A_pe,1));
    D=0;
    sys_continuous = ss(A,B,C,D);
    
    sysd = c2d(sys_continuous,Ts);
    
    A=sysd.A;  
    B=sysd.B;
    
    constant_component = function_at_point+A*(-1.*x_pe)+B*(-1.*u_pe);
    
end
    