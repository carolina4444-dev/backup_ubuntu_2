
function[total_error] = lagrange_remainder_multi_variable(iterative_and_aprox_point)
 
   global minimum_acceptable_distance radius f lreminder_function aprox_degree total_linearization_points...
       n_variables number_of_state_vars number_of_input_vars;

   x = iterative_and_aprox_point(1:n_variables);
   aprox_point_ = iterative_and_aprox_point(n_variables+1:end);
   aprox_point=format_to_shape(aprox_point_,[total_linearization_points,n_variables])';
   
%     for idx=1:total_linearization_points
%        if any(abs(x-aprox_point(:,idx)')<minimum_acceptable_distance, [1,2]) || any(abs(diff(aprox_point,2))<minimum_acceptable_distance, [1,2])
%            total_error = 9e+999; 
%            return
%        end
%     end
   
   %get global states and actuations
   symbolic_array_str = {};
   for idx=1:number_of_state_vars
       eval(strcat('global x',string(idx),';'))
       symbolic_array_str{idx}=string(strcat('x',num2str(idx),','));
   end
   for idx=1:number_of_input_vars
       eval(strcat('global u',string(idx),';'))
       symbolic_array_str{idx+number_of_state_vars}=string(strcat('u',num2str(idx),','));
   end
   %cut last comma
   symbolic_array = cell2mat(strcat(symbolic_array_str{:}));
   symbolic_array=symbolic_array(1:end-1);
   
   %f may have several components, considering hessian for this specific
   %problem
   derivative_term = {};
   for idx=1:length(f)
       current_component = f{idx};
       derivative_term{idx} = eval(strcat('hessian(current_component,[',symbolic_array,']);'));
   end
   factorial_term = factorial(aprox_degree+1);
   
   %lagrage remainder calculation, for each component (lines) and for each
   %linearization point
   lag_rem = {};
   point_n=1;
   for component_n=1:size(f,1) %component (lines)
        for idx=1:total_linearization_points %linearization point (columns)
%             if any(x-aprox_point(idx,:)'==0,[1,2])
%                 total_error = 9e+999; 
%                 return
%             end
            %-1* because it will be maximized
            lag_rem{component_n,point_n} = -1*((derivative_term{1,component_n}/factorial_term).*power(x-aprox_point(:,idx)',aprox_degree+1)); 
            point_n = point_n+1;
        end
        point_n=1;
   end
   

   %x_star is the evaluation point of the lagrange error
   %lets set it as the current x
%    x_star = mat2cell(x, n_variables);
%    
%    %preform substitutions, possibly division by zero
%    try
%        temp = eval(strcat('subs(lag_rem,{',symbolic_array,'}',char(39),', x_star);'));
%    catch e
%        total_error = 9999999999999999999999; 
%        return;
%    end
%     total_error = sum(sum(abs(eval(temp))));
    total_error=0;
       
    %slice aprox_points array into correct shape for combvec
    comb_vec_argument = {};
    for m=1:n_variables
        comb_vec_argument{m} = strcat("aprox_point(",num2str(m),",:)",", ");
    end
    comb_vec_argument = cell2mat(strcat(comb_vec_argument{:}));
    comb_vec_argument = extractBetween(comb_vec_argument,1,strlength(comb_vec_argument)-2);
    model_lin_points = eval(strcat("combvec(",comb_vec_argument{:},")"));
    total_model_lin_points = size(model_lin_points,2)*size(model_lin_points,1)/n_variables;
    %model_lin_points = format_to_shape(model_lin_points, [1,total_model_lin_points*n_variables]);
    
    global func symbolic_array
    for n_lin_point=1:total_model_lin_points
        for line=1:size(lag_rem,1)
            for col=1:size(lag_rem,2)
        
                x0 = x;
                lb = min(x, model_lin_points(:,n_lin_point)');
                ub = max(x, model_lin_points(:,n_lin_point,:)');
                %options = optimoptions('fmincon','Display','iter','OutputFcn',@outfun);
                %nonlcon = @mycon;
                func = lag_rem{line,col};
                
                [x_max_error, max_error] = fmincon(@max_lag_rem,x0,[],[],[],[],lb,ub);

                total_error=total_error+max_error;
            end
        end
    end
   
   %lagrange error being zero, redundant case <-> analysing same place as
   %the linearization point
   total_error
end