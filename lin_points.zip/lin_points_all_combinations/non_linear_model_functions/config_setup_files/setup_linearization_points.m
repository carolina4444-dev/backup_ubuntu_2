%*************************************
% % VARIABLES DEFINED HERE:
% linearization points, membership functions centers
%*************************************
run('./non_linear_model_functions/config_setup_files/setup_non_linear_expressions.m')
% linearization points set, use format name = choosed_model_points_mode_X
run('./non_linear_model_functions/config_setup_files/setup_min_max_range.m')

total_linearization_points = 2; % <-> total_fuzzy_sets por universo de discurso, shape=(n_variables)

%=fuzzy set maximum support/2, assuming simetry
radius = [0.3, 0.3, 0.3, 2, 2];

minimum_acceptable_distance = 0.05;

x0=[0.5, 0.1, 0.3, 2.0, 3.0;...
    0.4, 0.2, 0.6, 1.0, 4.0;...
    0.3, 0.6, 0.2, 3.0, 5.0;...
    ];

f = {dx1_dt;dx2_dt;dx3_dt};


domain = [STATES_RANGE;...%iteration variables
    INPUTS_RANGE;...%iteration variables
    STATES_RANGE;...%lin point 1
    INPUTS_RANGE;...%lin point 1
    STATES_RANGE;...%lin point 2
    INPUTS_RANGE;...%lin point 2
    ];
aprox_degree = 1;   %taylor series aproximation order

%run('/home/carolina/Documentos/lin_points_all_combinations/lin_points_multi_variable.m')
load('/home/carolina/Documentos/lin_points_all_combinations/found_lin_points.mat') %uncomment when script runed alleready

choosed_model_points=aprox_points_final';
% choosed_model_points={pi/180.*[-85:20:85],... %abs_X1, radians
%     [-10:5:10],...%abs_X2, radians
%     [-5:2.5:5]};%abs_u

% definir pontos de linearizacao em radianos e model_pois_mode_option

